package com.wunmansho.memeroller;


import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;

import android.view.View;
import android.view.animation.RotateAnimation;

import com.google.android.material.appbar.AppBarLayout;

import com.google.android.material.tabs.TabLayout;


import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import static androidx.constraintlayout.widget.Constraints.TAG;
import static com.wunmansho.util.utils.splitFileExt;
//import java.io.FileOutputStream;


public class PhotoGalleryActivity extends AppCompatActivity {


    private File file;
    private File favorite;
    private File popular;
    private File saved;
    private File newnew;
    private List<PicturesInfo> picturesinfo;
    private RecyclerView photoGalleryAdapter;
    private RotateAnimation rotateAnimation;
    private Intent intent;
    private Intent fullScreenIntent;
    private String albumName;

    private File mStorageDirectory;
    private String[] FilePathStrings;
    private String[] FileNameStrings;
    private String[] FileNameStrings1;
    private String[] FileNameStringsFinal;
    private File[] listFile;
    private Toolbar toolbar;
    private AppBarLayout appBarLayout;
    private TabLayout tabLayout;

    private int _selectedTab;     // 0 all 1 new 2 popular 3 favorite 4 saved
    private int albumCategory;
    private int allAlbums;
private View view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.photo_gallery_adapter);

        photoGalleryAdapter = findViewById(R.id.photoGalleryAdapter);
        int numberOfColumns = 3;
        photoGalleryAdapter.setLayoutManager(new GridLayoutManager(this, numberOfColumns));
        appBarLayout = findViewById(R.id.appbar);
        toolbar = findViewById(R.id.toolbar);
        tabLayout = findViewById(R.id.tabs);


        appBarLayout.setExpanded(false);
        appBarLayout.setActivated(false);
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                 // 0 all 1 new 2 popular 3 favorite 4 saved
                _selectedTab = tab.getPosition();
                initializeData();
                initializeAdapter();


            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
// 1 all 2 new 3 popular 4 favorite 5 saved
        _selectedTab = 0;
        initializeData();
        initializeAdapter();

    }

    private void initializeData() {
        picturesinfo = new ArrayList<>();


        if (!Environment.getExternalStorageState().equals(
                Environment.MEDIA_MOUNTED)) {
        } else {
            // Locate the image folder in your SD Card
            albumName = "MemeRoller";

            file = new File(Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_PICTURES), albumName);
            file.mkdirs();
            // 0 all 1 new 2 popular 3 favorite 4 saved
           // _selectedTab
            if (_selectedTab == 0 || _selectedTab == 1) {
                albumName = "MemeRoller/newnew";

                newnew = new File(Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_PICTURES), albumName);
                newnew.mkdirs();
            }
            // 0 all 1 new 2 popular 3 favorite 4 saved
            // _selectedTab
            if (_selectedTab == 0 || _selectedTab == 2) {
                albumName = "MemeRoller/popular";

                popular = new File(Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_PICTURES), albumName);
                popular.mkdirs();
            }
            // 0 all 1 new 2 popular 3 favorite 4 saved
            // _selectedTab
            if (_selectedTab == 0 || _selectedTab == 3) {
                albumName = "MemeRoller/favorite";

                favorite = new File(Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_PICTURES), albumName);
                favorite.mkdirs();
            }
            // 0 all 1 new 2 popular 3 favorite 4 saved
            // _selectedTab
            if (_selectedTab == 0 || _selectedTab == 4) {
                albumName = "MemeRoller/saved";

                saved = new File(Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_PICTURES), albumName);
                saved.mkdirs();
            }

        }

        if (file.isDirectory()) {


                listFile = file.listFiles();
                // Create a String array for FilePathStrings
                FilePathStrings = new String[listFile.length];
                FileNameStrings = new String[listFile.length];
                allAlbums = 0;
                for (albumCategory = 0; albumCategory < listFile.length; albumCategory++) {
                    // Get the path of the image file

                    FilePathStrings[albumCategory] = listFile[albumCategory].getAbsolutePath();
                    if (splitFileExt(FilePathStrings[albumCategory]).equals("jpg") || splitFileExt(FilePathStrings[albumCategory]).equals("png") || splitFileExt(FilePathStrings[albumCategory]).equals("gif")) {
                        picturesinfo.add(new PicturesInfo(FilePathStrings[albumCategory]));
                    }
                    // Get the name image file
                    FileNameStrings[albumCategory] = listFile[albumCategory].getName();
                    //   FileNameStrings[i] = "The Wiz";
                    allAlbums++;

                }


            // 0 all 1 new 2 popular 3 favorite 4 saved
            // _selectedTab
            if (_selectedTab == 0 || _selectedTab == 1) {
                listFile = newnew.listFiles();
                // Create a String array for FilePathStrings
                FilePathStrings = new String[listFile.length];
                FileNameStrings = new String[listFile.length];
                allAlbums = 0;
                for (albumCategory = 0; albumCategory < listFile.length; albumCategory++) {
                    // Get the path of the image file

                    FilePathStrings[albumCategory] = listFile[albumCategory].getAbsolutePath();
                    if (splitFileExt(FilePathStrings[albumCategory]).equals("jpg") || splitFileExt(FilePathStrings[albumCategory]).equals("png") || splitFileExt(FilePathStrings[albumCategory]).equals("gif")) {

                        picturesinfo.add(new PicturesInfo(FilePathStrings[albumCategory]));
                    }
                    // Get the name image file
                    FileNameStrings[albumCategory] = listFile[albumCategory].getName();
                    //   FileNameStrings[i] = "The Wiz";
                    allAlbums++;

                }
            }

            // 0 all 1 new 2 popular 3 favorite 4 saved
            // _selectedTab
            if (_selectedTab == 0 || _selectedTab == 2) {
                listFile = favorite.listFiles();
                // Create a String array for FilePathStrings
                FilePathStrings = new String[listFile.length];
                FileNameStrings = new String[listFile.length];
                allAlbums = 0;
                for (albumCategory = 0; albumCategory < listFile.length; albumCategory++) {
                    // Get the path of the image file

                    FilePathStrings[albumCategory] = listFile[albumCategory].getAbsolutePath();
                    if (splitFileExt(FilePathStrings[albumCategory]).equals("jpg") || splitFileExt(FilePathStrings[albumCategory]).equals("png") || splitFileExt(FilePathStrings[albumCategory]).equals("gif")) {

                        picturesinfo.add(new PicturesInfo(FilePathStrings[albumCategory]));
                    }
                    // Get the name image file
                    FileNameStrings[albumCategory] = listFile[albumCategory].getName();
                    //   FileNameStrings[i] = "The Wiz";
                    allAlbums++;

                }
            }

            // 0 all 1 new 2 popular 3 favorite 4 saved
            // _selectedTab
            if (_selectedTab == 0 || _selectedTab == 3) {
                listFile = popular.listFiles();
                // Create a String array for FilePathStrings
                FilePathStrings = new String[listFile.length];
                FileNameStrings = new String[listFile.length];
                allAlbums = 0;
                for (albumCategory = 0; albumCategory < listFile.length; albumCategory++) {
                    // Get the path of the image file

                    FilePathStrings[albumCategory] = listFile[albumCategory].getAbsolutePath();
                    if (splitFileExt(FilePathStrings[albumCategory]).equals("jpg") || splitFileExt(FilePathStrings[albumCategory]).equals("png") || splitFileExt(FilePathStrings[albumCategory]).equals("gif")) {

                        picturesinfo.add(new PicturesInfo(FilePathStrings[albumCategory]));
                    }
                    // Get the name image file
                    FileNameStrings[albumCategory] = listFile[albumCategory].getName();
                    //   FileNameStrings[i] = "The Wiz";
                    allAlbums++;

                }
            }


            // 0 all 1 new 2 popular 3 favorite 4 saved
            // _selectedTab
            if (_selectedTab == 0 || _selectedTab == 4) {
                listFile = saved.listFiles();
                // Create a String array for FilePathStrings
                FilePathStrings = new String[listFile.length];
                FileNameStrings = new String[listFile.length];
                allAlbums = 0;
                for (albumCategory = 0; albumCategory < listFile.length; albumCategory++) {
                    // Get the path of the image file

                    FilePathStrings[albumCategory] = listFile[albumCategory].getAbsolutePath();
                    if (splitFileExt(FilePathStrings[albumCategory]).equals("jpg") || splitFileExt(FilePathStrings[albumCategory]).equals("png") || splitFileExt(FilePathStrings[albumCategory]).equals("gif")) {

                        picturesinfo.add(new PicturesInfo(FilePathStrings[albumCategory]));
                    }
                    // Get the name image file
                    FileNameStrings[albumCategory] = listFile[albumCategory].getName();
                    //   FileNameStrings[i] = "The Wiz";
                    allAlbums++;

                }
            }

        }





//        String StoredPathString = "storage/emulated/0/Pictures/AccidentReport/ACC_20190313_2000321244976799.jpg";
//        picturesinfo.add(new PicturesInfo(StoredPathString));

    }


    private void initializeAdapter() {
        PhotoGalleryAdapter adapter = new PhotoGalleryAdapter(getApplicationContext(), picturesinfo, (v, position) -> {
            //   Toast.makeText(PhotoGalleryActivity.this, "Clicked Item: "+position,Toast.LENGTH_SHORT).show();
            String image = picturesinfo.get(position).photoId;
            String fileExt = splitFileExt(image);
            fullScreenIntent = new Intent(PhotoGalleryActivity.this, EditImageActivity.class);
            fullScreenIntent.putExtra("DA_IMAGE", image);
            startActivity(fullScreenIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP));


        });
        photoGalleryAdapter.setAdapter(adapter);
    }


    public void doClose() {

    }

    @Override
    public void onBackPressed() {
        doClose();
        finishAffinity();
        System.exit(0);
//        intent = new Intent(this, MultiMediaMenu.class);
//        startActivity(intent);
    }

    private void copyFile(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[1024];
        int read;
        while ((read = in.read(buffer)) != -1) {
            out.write(buffer, 0, read);
        }
    }
}
