package com.wunmansho.memeroller;

import android.view.View;

/**
 * Created by muhammadriyaz on 23/07/15.
 */
interface CustomItemClickListener {
    void onItemClick(View v, int position);
}
