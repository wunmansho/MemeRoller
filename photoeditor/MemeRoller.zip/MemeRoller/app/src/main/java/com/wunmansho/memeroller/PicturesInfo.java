package com.wunmansho.memeroller;

class PicturesInfo {
    //  String name;
    //  String age;
    final String photoId;

    //  PicturesInfo(String name, String age, int photoId) {
    PicturesInfo(String photoId) {
        //      this.name = name;
        //     this.age = age;
        this.photoId = photoId;
    }
}